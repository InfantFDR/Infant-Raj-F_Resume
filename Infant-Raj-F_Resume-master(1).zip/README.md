# Infant Raj F_Resume
The Infant Raj F_Resume folder contains .tex file, .pdf file and other supporting files which are created in Latex software. My resume PDF file named as Infant Raj F_Resume is inside the folder.
